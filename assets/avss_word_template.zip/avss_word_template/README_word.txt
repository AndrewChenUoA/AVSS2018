
In order to prepare a submission for double-blind review, please use "avss_template_for_review.docx".

When ready for the final submission please use "avss_template_final.docx" - complete the title and author fields, insert paper content from "avss_template_for_review.docx" while simultaneously carrying out revisions recommended by reviewers. Make sure that there are no line and page numbers in the final version.
